<?php 
include('templates/sidebar.php')
?>